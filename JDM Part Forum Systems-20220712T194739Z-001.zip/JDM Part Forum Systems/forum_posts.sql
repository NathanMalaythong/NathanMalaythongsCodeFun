-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 24, 2021 at 10:57 AM
-- Server version: 5.7.34
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `natesaek_newdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `forum_posts`
--

CREATE TABLE `forum_posts` (
  `post_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `post_text` text,
  `post_create_time` datetime DEFAULT NULL,
  `post_owner` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_posts`
--

INSERT INTO `forum_posts` (`post_id`, `topic_id`, `post_text`, `post_create_time`, `post_owner`) VALUES
(1, 1, 'It is nasty and I dont like cole slaw. ENOUGH SAID. I made my point. Good Bye!', '2021-04-12 11:23:04', 'nathanM@gmail.com'),
(2, 1, 'I honestly agree with you!  As the superstar famous actor I also believe that cole slaw should be banished from the Earth', '2021-04-12 11:24:27', 'bradPitt@famousPeople.yahoo.com'),
(3, 2, 'I enjoy coming to work everyday and cooking Krabby Patties for our customers and hanging out with my best friend Squidward!', '2021-04-12 11:26:16', 'SpongebobSquarepants@bikinibottom.com'),
(4, 2, 'I am NOT your best friend Spongebob!', '2021-04-12 11:26:49', 'Squidward@bikinibottom.com'),
(5, 3, 'It Really looks like a gundam wing, dont ya think?', '2021-04-22 12:31:56', 'GundamBuilder69@gmail.com'),
(6, 4, 'I am located in SC, and would like to buy a Kouki conversion kit for my s14 for $5000. LMK at my email!', '2021-04-22 12:45:34', 'KoukiStanS14@ymail.com'),
(7, 5, 'Hey! Do you want to convert your boring R32 Gtst To a baller R32 GTR.  We have finally opened pre orders for the GTR Conversion kit at UPGARAGE.jp', '2021-04-22 13:41:36', 'specialstagewest@finalbout.com'),
(8, 6, 'I am looking for a graphic design shop that can commission and print me an Itasha for my s13 with the girl group Loona on it.  Thanks!', '2021-04-22 13:43:11', 'StanLoona42@google.com'),
(9, 7, 'I lost my Blow Off Valve, I need it back.  Well someone stole it actually', '2021-04-23 11:42:10', 'brucelee@karate.com'),
(10, 8, 'A pair of real Nismo car mats FS.   $300 OBO, message me at my email below.', '2021-04-23 11:43:05', 'rocklee@konoha.org'),
(11, 9, 'I am in the Upstate New York area and looking for a R34 GTR conversion for my GTST let me know at my email. PLZ. CASH IN HAND.', '2021-04-23 11:44:25', 'itachiboi@gmail.com'),
(12, 10, 'A new Kei Car drift even will be going down at Road Atlanta in 2 months.  Please RSVP so we can get a quick headcount for the event.  ', '2021-04-23 11:45:31', 'minato@konohavillage.org'),
(13, 11, 'Anyone want to trade cars looking for mint condition JZX100!', '2021-04-23 11:46:31', 'BritneySpears@music.com'),
(14, 12, 'We have a new 21 Boost Blue Type R in the showroom right now. Come and Look at it maybe buy it?  Dick Brooks Honda.', '2021-04-23 11:54:12', 'dickbrookshonda@honda.com'),
(15, 13, 'I am wanting to wrap my s2000 Pink like Suki from 2F&2F. Hit me up at my email. ', '2021-04-23 11:55:20', 'egirl92@gmail.com'),
(16, 14, 'Get an exclusive look at the new 400Z nismo edition coming soon to our Headquarters.', '2021-04-23 11:57:11', 'nismoHQ@nismo.com'),
(17, 15, 'Just got a whole christmas tree on my dash.  Looking for someone to delete the codes.', '2021-04-23 11:58:19', 'patrickstar@bikinibottom.com'),
(18, 16, 'WTB a clean R30 with no mods or anyhthing just clean body.  LMK', '2021-04-23 11:59:28', 'r30guy@bandainamco.co'),
(19, 17, 'we are finally bringing UPGARAGE JP to the states and will be offering our services in America. COMING SOON!', '2021-04-23 12:00:35', 'DJKhaled@gmail.com'),
(20, 18, 'Excel.JP will be holding the annual Grassroots drift event later this year.  Beginners welcome!', '2021-04-23 12:01:19', 'turn10@gmail.com'),
(21, 19, 'Drop by UpGarage this afternoon to purchase our new Tsurikawas', '2021-04-23 12:02:20', 'midara@naruto.com'),
(22, 20, 'Lets start a forum to talk about ITR\'s right here right now.', '2021-04-23 12:03:04', 'hondaprojason@yahoo.com'),
(23, 21, 'WTB a clean set of 3 piece wheels. any brand got 3k in hand', '2021-04-23 12:03:45', 'BTSstan99@yahoo.com'),
(24, 22, 'Got some Bazreias for sale 2.5k wheels specs above.  Hit me up!', '2021-04-23 12:04:40', 'wheelguy420@threepiece.us'),
(25, 23, 'Got some XR4s in the moistboys spec 15x9 +0 for 1.2k ', '2021-04-23 12:05:20', 'karuma@karumalimited.co'),
(26, 24, 'Got some meisters for sale in 5x114.3 GTR specs. can negotiate price.', '2021-04-23 12:06:11', 'moistboys@moistboys.co'),
(27, 25, 'This car i dont like it no more.  Someone trade me something cooler plz', '2021-04-23 12:07:14', 'preludedriver@dookieville.com'),
(28, 26, 'Get ready to see our new line of wheels coming out in SUMMER 21', '2021-04-23 12:07:48', 'WorkWheels@workwhels.co'),
(29, 27, 'There are not many euro guys in Japan, we need more plz join this forum so we can talk', '2021-04-23 12:08:22', 'bmwJapan@bmw.jp'),
(30, 23, 'Let me buy these im from ATL, Georgia. Heres my phone number 888-888-8888', '2021-04-23 12:12:57', 'bricksquad24@wakaflocka.com'),
(31, 24, 'I would like to know if you can negotiate price on these. I Got 1.9K with your name on it.', '2021-04-23 12:26:41', 'dookieboi69@gmail.com'),
(32, 28, 'I am deciding if i want to buy a chaser or buy a cefiro.  Let me know on the differences in this forum', '2021-04-23 12:40:17', 'rubberduck82@gmail.com'),
(33, 29, 'WE have a WMMT5dx group and are looking for new members.  Located at ROUND1 Arcade in Greensboro, NC.', '2021-04-23 12:41:48', 'GokuStan@gmail.com'),
(34, 30, 'We are also looking for new members to join the better arcade game Initial D Arcade Stage located at ROUND1 in Greensboro, NC', '2021-04-23 12:42:39', 'GohanIsDead@yahoo.com'),
(35, 31, 'Looking for people with Itasha car\'s and would like to join our group Located in ATL area in Georgia. All Itasha builds welcome.', '2021-04-23 12:44:14', 'meguminsHusband@gmail.com'),
(36, 32, 'WTB a clean or semi-clean GC8 in the ATL area with 5k cash in hand ready for you.  Will Drive 2 hours away MAX!!!', '2021-04-23 12:48:31', 'hyewonStan@gmail.com'),
(37, 33, 'WTB a FC rx7 in the charlotte area, got 5k in hand ready to be yours', '2021-04-23 14:53:48', 'natesaekki@lcs.com'),
(38, 34, 'looking to buy ae86 trueno in the upstate area, any body styling is fine. lmk', '2021-04-23 14:55:00', 'takumifujiwara@tofushop.com'),
(39, 32, 'I got one for sale for even cheaper my dudes hit me up!', '2021-04-23 14:55:38', 'boostedboiz@youtube.com'),
(40, 35, 'WTB a Greddy DDR Exhaust for a 21 Type R, let me know at my email if you got one', '2021-04-23 14:56:54', 'buntasson@tofushop.com'),
(41, 36, 'I got fs/ft a NA miata clean body with 95k original miles on it with a hardtop. Come look at it ', '2021-04-23 14:59:20', 'fatezerosaberisbae@gmail.com'),
(42, 37, 'Come to Enjuku Performance we have Yashio Factory Hoodies in stock right now!', '2021-04-23 15:35:28', 'sammitfan29@gmail.com'),
(43, 38, 'At enjuku Performance we now offer Square G33 wheels are back in town, best r33 reps ever made', '2021-04-23 15:36:09', 'r32guy@yahoo.com'),
(44, 39, 'At Systemotorsports, the te37 OG\'s are back for the fall season with pre orders opening up as fast as next week.', '2021-04-23 15:37:32', 'yasuofan@lol.com'),
(45, 40, 'I had a set of rep wheels and hit a pothole, it flipped my car 20 times and stole my girlfriend. 0/10 wont buy again!~', '2021-04-23 15:38:08', 'te37god@mail.com'),
(46, 41, 'Which wheel do yall like better Kranze\'s or Ceberuses, Honestly I love both', '2021-04-23 15:38:53', 'KranzeOverWorks@threepiece.us'),
(47, 42, 'Looking for a set of 57drs in 5x120 19x9.5 which are type r specs plz notify me when back instock or if ur selling a set', '2021-04-23 15:40:12', 'dookieboi42@yahoo.com'),
(48, 43, 'Color In Lime Green, was used on RC350.', '2021-04-23 15:43:34', 'TridentGumLover@88rising.com'),
(49, 44, 'Looking to buy some RCA\'s for my FA5, preferably wanting some Skunk2 branded RCA\'s', '2021-04-23 15:46:32', 'intelfan@dell.com'),
(50, 45, 'Wanting to weld and extend your lower control arms for more angle, come visit us today at Excel.jp Speed Shop!', '2021-04-23 15:47:16', 'randomshop@gmail.com'),
(51, 46, 'Come buy an angle kit from us at Excel.jp Speed Shop, we have angle kits for your GT86 for some dank ass front camber and angle', '2021-04-23 15:49:39', 'supbirdy@yahoo.com'),
(52, 47, 'Im in the charlotte area and want to rent a trailer for a few hours to pick up my car from the import shop', '2021-04-23 15:51:04', 'ILoveArin@gmail.com'),
(53, 48, 'List of Parts for a DC5 i have for sale are seats, coilovers, and chargespeed front bumper', '2021-04-23 15:51:53', 'jenniekimlover@gmail.com'),
(54, 49, 'Which show do yall like better, even thought their about two whole different styles of racing.', '2021-04-23 15:52:45', 'jisookimstan@blackpink.com'),
(55, 50, 'I got a Lan EVO for sale and trade, looking for anything rwd and jdm, must offer at least of 10k or I will not respond to u broke BOI!', '2021-04-23 15:53:41', 'izone@mbc.kr'),
(56, 51, 'Desmond Regamasters will be returning next month for purchase after being discontinued for about 10 years.', '2021-04-23 15:55:08', 'ihatekpop@gmail.com'),
(57, 52, 'Enjuku Racing has horrible customer service and wont refund me a broken part that came in the mail.  DO NOT DO BUSINESS WITH THEM!', '2021-04-23 15:56:27', 'eunbi@izone.com'),
(58, 53, 'The best and only R33 reps i can find are Square G33\'s and their the best reps purchase I have ever made!', '2021-04-23 15:57:10', 'joyuri@izone.com'),
(59, 39, 'Oh boi, im defintely going to sell my left kidney to afford these wheels and you bet ima get me a set!', '2021-04-23 15:57:48', 'chaewon@izone.com'),
(60, 23, 'No let me buy them I have more money to offer and they will be going on a Moist R30 and will look better than this guys car!', '2021-04-23 15:58:37', 'yena@izone.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `forum_posts`
--
ALTER TABLE `forum_posts`
  ADD PRIMARY KEY (`post_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `forum_posts`
--
ALTER TABLE `forum_posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
