<?php
$mysqli = NEW MySQLi("Enter your own credentials to database");
$resultSet = $mysqli->query("SELECT topic_title FROM forum_topics");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Report Page</title>
  <style>
  body{
    background-image: url('images/upgarage.jpg');
    background-position: center;
    background-repeat: repeat;
    background-size: cover;
    position: relative;
  }
  h1{
text-align: center;
  margin-top: 9%;
  background-color: red;
  width: fit-content;
  block-size: fit-content;
  color: white;
  border-style: outset;
  border-color: navy;
  padding: 20px;
  margin-left: 38%;
}
form{
  background-color: yellow;
  color: white;
  border-color: navy;
  padding: 20px;
  margin-left: 28%;
}
form p{
font-size: 15px;
text-align: center;
}
button{
padding: 10px;
margin-top:4px;
}
button:hover{
background-color: red;
}
  </style>
</head>
<body>
  <?php include 'navbar.php';  ?>
  <main>
    <h1>Send Report About A Post</h1>
    <form class="contact-form" action="reportposts.php" method="post">
      <input type="text" name="reportEmail" placeholder="Your E-Mail">
      <select name="postToReport">
        <?php
        while($rows = $resultSet->fetch_assoc()){
          $reportPost = $rows['topic_title'];
          echo "<option value='$reportPost'>$reportPost</option>";
        }
        ?>
      </select>
      <input type="text" name="reportMsg" placeholder="Reason For Report">
      <button type="submit" name="reportBtn">Send Report</button>
    </form>
  </main>
</body>
</html>
