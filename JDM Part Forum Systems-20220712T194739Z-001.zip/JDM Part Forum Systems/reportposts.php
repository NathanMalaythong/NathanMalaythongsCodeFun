<?php
$con = mysqli_connect("Enter Your Own Credentials For Your Database");

if(isset($_POST['reportBtn'])){
  $email = $_POST['reportEmail'];
  $reportedPost = $_POST['postToReport'];
  $reason = $_POST['reportMsg'];

  $sql = "INSERT INTO reported_posts (email, post, reason) VALUES ('$email', '$reportedPost', '$reason')";

  if(!mysqli_query($con,$sql)){
    echo 'Failed to Report';
  } else {
    echo 'Report Sent Successfully';
  }
  header("refresh:2; url=topiclist.php");

}


?>
