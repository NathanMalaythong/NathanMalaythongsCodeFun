<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8";>
  <title>Navbar</title>
  <style type="text/css">
  *{
    padding: 0;
    margin: 0;
    text-decoration: none!important;
  }
  #navbar {
    width: 100%;
    background: red;
    	text-decoration: none!important;

  }
  #navbar ul{
    list-style-type:none;
    text-align: center;
    text-decoration: none;

  }
  #navbar li {
    display: inline-block;
    padding:5px;
    color: white;
    font-size: 30px;
    background-color: navy;
    border-style: groove;
    border-color: yellow;
    border-width: 7px;
  }
  #navbar a{
  text-decoration: none!important;
  color:white;
  }
  #navbar a:hover{
  background: yellow;
  color: black;
  }
  </style>
</head>
<body>
  <div id="navbar">
    <ul>
      <li><a href="index.html">Home Page</li>
      <li><a href="addtopic.html">Add A Part/Car</li>
      <li><a href="topiclist.php">Parts List Forum</li>
      <li><a href="thanossnap.php">Clean the Garage</li>
      <li><a href="reportpage.php">Report a Post</li>
      </a>
    </ul>
  </div>
</body>
</html>
