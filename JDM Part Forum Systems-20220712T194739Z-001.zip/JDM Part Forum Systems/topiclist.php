<?php
include 'db_include.php';
doDB();

//gather the topics
$get_topics_sql = "SELECT topic_id, topic_title, DATE_FORMAT(topic_create_time,  '%b %e %Y at %r') as fmt_topic_create_time, topic_owner FROM forum_topics ORDER BY topic_create_time DESC";
$get_topics_res = mysqli_query($mysqli, $get_topics_sql) or die(mysqli_error($mysqli));

if (mysqli_num_rows($get_topics_res) < 1) {
	//there are no topics, so say so
	$display_block = "<p><em>No topics exist.</em></p>";
} else {
	//create the display string
    $display_block = <<<END_OF_TEXT
    <table id="myTable">
    <thead>
    <tr>
    <th><a href="javascript:sortTable(myTable,0,0);">TOPIC TITLE</a></th>
    <th><a href="javascript:sortTable(myTable,1,0);"># of POSTS</a></th>
    </tr>
    </thead>
    <tbody>
END_OF_TEXT;

	while ($topic_info = mysqli_fetch_array($get_topics_res)) {
		$topic_id = $topic_info['topic_id'];
		$topic_title = stripslashes($topic_info['topic_title']);
		$topic_create_time = $topic_info['fmt_topic_create_time'];
		$topic_owner = stripslashes($topic_info['topic_owner']);

		//get number of posts
		$get_num_posts_sql = "SELECT COUNT(post_id) AS post_count FROM forum_posts WHERE topic_id = '".$topic_id."'";
		$get_num_posts_res = mysqli_query($mysqli, $get_num_posts_sql) or die(mysqli_error($mysqli));

		while ($posts_info = mysqli_fetch_array($get_num_posts_res)) {
			$num_posts = $posts_info['post_count'];
		}

		//add to display
		$display_block .= <<<END_OF_TEXT
		<tr>
		<td><a href="showtopic.php?topic_id=$topic_id"><strong>$topic_title</strong></a><br>
		Created on $topic_create_time by $topic_owner</td>
		<td class="num_posts_col">$num_posts</td>
		</tr>
END_OF_TEXT;
	}
	//free results
	mysqli_free_result($get_topics_res);
	mysqli_free_result($get_num_posts_res);

	//close connection to MySQL
	mysqli_close($mysqli);

	//close up the table
	$display_block .= "</tbody>
	</table>";
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Topics in My Forum</title>
  <style type="text/css">
	body{
	  background-image: url('images/upgarage.jpg');
	  background-repeat: repeat;
	}
	h1{
	  text-align: center;
	  margin-top: 6%;
	  background-color: red;
	  width: fit-content;
	  block-size: fit-content;
	  color: black;
	  border-style: solid;
	  border-color: black;
	  padding: 40px;
	  margin-left: 43%;
	}
	table {
	text-align: center;
	border: 4px solid black;
	border-collapse: collapse;
	text-align: center;
	margin-left: 32%;'
	margin: 25px 0;
	}
	th{
	border: 4px solid yellow;
			padding: 6px;
			font-weight: bold;
			background: navy;
	        color: white;
	        font-size:35px;

	}
	td{
		border: 4px solid yellow;
			padding: 6px;
	        background: white;
	        color: red;
	        font-size: 20px;
	        font-weight: bold;
	}

	#report h1{
	background-color: white;
	font-size: 15px;
	margin-left:0;
	position: fixed;
	padding: 5px;
	top:40%;
	}
	#putin h1{
	background-color: white;
	font-size: 15px;
	margin-left:0;
	margin-top: 5px;
	position: fixed;
	padding: 5px;
	top:60%;
	}


	.num_posts_col { text-align: center; }

  </style>

  <script type="text/javascript">
  function sortTable(table, col, reverse) {
     var tb = table.tBodies[0];
     var tr = Array.prototype.slice.call(tb.rows, 0);
     var  i;
     reverse = -((+reverse) || -1);
     tr = tr.sort(function (a, b) {
       return reverse // `-1 *` if want opposite order
          * (a.cells[col].textContent.trim()
               .localeCompare(b.cells[col].textContent.trim())
             );
     });
     for(i = 0; i < tr.length; ++i) tb.appendChild(tr[i]);
   }
   // sortTable(tableNode, columId, false);
  </script>
</head>
<body>
	<?php include 'navbar.php'; ?>
	<br>
  <h1>JDM Parts Forum </h1>
	<div id="report">
	<h1>See An Inappropriate Post<p>Click here to report</p>
	<p><a href="reportpage.php">Report</a></p></h1>
	</div>
	<br>
	<div id="putin">
	<h1>Want To Add Topic?
	<p><a href="addtopic.html">Add Topic!</a></p></h1>
	</div>
  <?php echo $display_block; ?>
</body>
</html>
