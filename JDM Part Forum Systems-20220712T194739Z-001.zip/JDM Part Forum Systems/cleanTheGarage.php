<?php
$mysqli = mysqli_connect("Enter Credientials for Your SQL Database");

if (mysqli_connect_errno()) {
	printf("Connect failed: %s\n", mysqli_connect_error());
	exit();
} else {
	//$clean_text_firstName = mysqli_real_escape_string($mysqli, $_POST['nameField']);
	//$sql = "INSERT INTO persons (first_name) VALUES ('".$clean_text_firstName."')";
  $sql = "DELETE FROM forum_topics";
	$res = mysqli_query($mysqli, $sql);

	if ($res === TRUE) {
	   	echo "The Garage Has been Cleansed";
	} else {
		printf("The avengers stopped you from snapping", mysqli_error($mysqli));
	}
	header("Location: topiclist.php");

	mysqli_close($mysqli);
}

 ?>
