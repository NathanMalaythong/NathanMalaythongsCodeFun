
<!DOCTYPE html>
<html>
  <head>
    <title>Tunnel To Doom</title>
    <style>
    body{
      background-image: url('images/thanosbackground.jpg');
      background-position: center;
      background-repeat: repeat;
      background-size: cover;
      position: relative;
    }
    h1{
  text-align: center;
	  margin-top: 9%;
	  background-color: purple;
	  width: fit-content;
	  block-size: fit-content;
	  color: white;
	  border-style: outset;
	  border-color: gold;
	  padding: 20px;
	  margin-left: 25%;
 }
 form{
	  background-color: purple;
    width: fit-content;
	  block-size: fit-content;
    font-size:30px;
	  color: white;
	  border-color: gold;
	  padding: 20px;
	  margin-left: 30%;
 }
 form p{
font-size: 15px;
text-align: center;
 }
 button{
 padding: 10px;
 margin-top:4px;
 }
 button:hover{
 background-color: red;
 }
    </style>
  </head>
  <body>
    	<?php include 'navbar.php'; ?>
                    <h1>Please Enter Admin Credentials To Access The Thanos Snap Button</h1>
                  <form action="thanosSnapLogin.php" method="POST">
                    <p style="text-align: center;"><label for="NameField">User Login:</label><br>
                    Username: <input type="text" name="thanosUsername" size="30">
                    Password:  <input type="password" name="thanosPass" size="30">
                    <br>
                    <button type="submit" name="snap">Access Armageddon Button</button>
                  </form>

  </body>
  </html>
