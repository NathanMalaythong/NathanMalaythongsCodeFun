<?php
$con = mysqli_connect("Enter Your Own Credentials For Your Database");
  if(isset($_POST['snap'])){
    $username = mysqli_real_escape_string($con, $_POST['thanosUsername']);
    $passwd = mysqli_real_escape_string($con, $_POST['thanosPass']);

    if($username!="" && $passwd!=""){
      $sql = "SELECT id FROM login WHERE username='$username' AND passwd='$passwd'";
      $result = mysqli_query($con, $sql);
      $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

      $count = mysqli_num_rows($result);
      if($count==1){
        header("location: armageddon.html");
      } else {
        echo '<script type="text/javascript">';
        echo ' alert("invalid login")';  //not showing an alert box.
        echo '</script>';
      }
    }
  }
?>
