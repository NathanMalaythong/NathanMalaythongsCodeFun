This is a project I worked on in a Web Development Class.
It is a Forum System Application with both front end and back end developemnt using HTML, JS, MyPHPAdmin, and SQL Queries.
It is a forum systemt targeting car enthiusiasts who are intrested in Japaneese Motor Vehicles.
