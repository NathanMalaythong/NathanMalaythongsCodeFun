-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 24, 2021 at 10:58 AM
-- Server version: 5.7.34
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `natesaek_newdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `forum_topics`
--

CREATE TABLE `forum_topics` (
  `topic_id` int(11) NOT NULL,
  `topic_title` varchar(150) DEFAULT NULL,
  `topic_create_time` datetime DEFAULT NULL,
  `topic_owner` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forum_topics`
--

INSERT INTO `forum_topics` (`topic_id`, `topic_title`, `topic_create_time`, `topic_owner`) VALUES
(1, 'Why Cole Slaw should be illegal!', '2021-04-12 11:23:04', 'nathanM@gmail.com'),
(2, 'Why I love working at the Krusty Krab', '2021-04-12 11:26:16', 'SpongebobSquarepants@bikinibottom.com'),
(3, 'Honda Civic Type R Rear Roof Spoiler', '2021-04-22 12:31:56', 'GundamBuilder69@gmail.com'),
(4, 'Anyone Can sell me a Kouki Conversion?', '2021-04-22 12:45:34', 'KoukiStanS14@ymail.com'),
(5, 'R32 GTR Conversion Kit - Open for Pre-Orders!', '2021-04-22 13:41:36', 'specialstagewest@finalbout.com'),
(6, 'Can anyone commission A Loona Itasha?', '2021-04-22 13:43:11', 'StanLoona42@google.com'),
(7, 'Any extra HKS BOVs anywhere?', '2021-04-23 11:42:10', 'brucelee@karate.com'),
(8, 'Nismo Car Mats for Sale!', '2021-04-23 11:43:05', 'rocklee@konoha.org'),
(9, 'R34 GTR Conversion WTB!', '2021-04-23 11:44:25', 'itachiboi@gmail.com'),
(10, 'Kei Car Drift Event! Coming Soon!', '2021-04-23 11:45:31', 'minato@konohavillage.org'),
(11, 'Want to Trade JZX90 for JZX100', '2021-04-23 11:46:31', 'BritneySpears@music.com'),
(12, '2021 Boost Blue Type R Just in.', '2021-04-23 11:54:12', 'dickbrookshonda@honda.com'),
(13, 'Looking for anyone who can Wrap.', '2021-04-23 11:55:20', 'egirl92@gmail.com'),
(14, '400Z nismo edition Coming soon.', '2021-04-23 11:57:11', 'nismoHQ@nismo.com'),
(15, 'can anyone delete my CEL codes.', '2021-04-23 11:58:19', 'patrickstar@bikinibottom.com'),
(16, 'Looking for a clean R30', '2021-04-23 11:59:28', 'r30guy@bandainamco.co'),
(17, 'UPGARAGE USA!!!!', '2021-04-23 12:00:35', 'DJKhaled@gmail.com'),
(18, 'Local Grassroots Drift Event - Excel.Jp ', '2021-04-23 12:01:19', 'turn10@gmail.com'),
(19, 'Tsurikawa\'s on sale now.', '2021-04-23 12:02:20', 'midara@naruto.com'),
(20, 'Integra Type R - Forum', '2021-04-23 12:03:04', 'hondaprojason@yahoo.com'),
(21, 'Looking for 3 Piece Wheels - WTB', '2021-04-23 12:03:45', 'BTSstan99@yahoo.com'),
(22, 'FS - Weds Kranze Bazreia\'s (18x11.5 + 5)', '2021-04-23 12:04:40', 'wheelguy420@threepiece.us'),
(23, 'FS/FT - SSR Longchamp XR4s ', '2021-04-23 12:05:20', 'karuma@karumalimited.co'),
(24, 'FS/FT - Work Meisters S1\'s (19x9.5)', '2021-04-23 12:06:11', 'moistboys@moistboys.co'),
(25, 'Wanna trade my Prelude', '2021-04-23 12:07:14', 'preludedriver@dookieville.com'),
(26, 'new wheels coming out SUMMER 2021', '2021-04-23 12:07:48', 'WorkWheels@workwhels.co'),
(27, 'European cars need some love too.', '2021-04-23 12:08:22', 'bmwJapan@bmw.jp'),
(28, 'Chaser vs Cefiro', '2021-04-23 12:40:17', 'rubberduck82@gmail.com'),
(29, 'Wangan Midnight Maximum Tune 5dx Group', '2021-04-23 12:41:48', 'GokuStan@gmail.com'),
(30, 'Initial D Arcade Group', '2021-04-23 12:42:39', 'GohanIsDead@yahoo.com'),
(31, 'Itasha Group ', '2021-04-23 12:44:14', 'meguminsHusband@gmail.com'),
(32, 'Looking For a GC8 in ATL Area', '2021-04-23 12:48:31', 'hyewonStan@gmail.com'),
(33, 'WTB - FC RX7 ', '2021-04-23 14:53:48', 'natesaekki@lcs.com'),
(34, 'WTB - AE86 Corolla ', '2021-04-23 14:55:00', 'takumifujiwara@tofushop.com'),
(35, 'Looking For A Greddy DDR Exhaust!', '2021-04-23 14:56:54', 'buntasson@tofushop.com'),
(36, 'FS/FT - Mazda Miata Na ', '2021-04-23 14:59:20', 'fatezerosaberisbae@gmail.com'),
(37, 'Yashio Factory Hoodies Avaliable Here!', '2021-04-23 15:35:28', 'sammitfan29@gmail.com'),
(38, 'Square G33 Back IN STOCK!', '2021-04-23 15:36:09', 'r32guy@yahoo.com'),
(39, 'TE37 Avaliable for Pre Orders!', '2021-04-23 15:37:32', 'yasuofan@lol.com'),
(40, 'Do NOT BUY Rep Wheels', '2021-04-23 15:38:08', 'te37god@mail.com'),
(41, 'Kranze Bazreia\'s vs Kranze Cerberus', '2021-04-23 15:38:53', 'KranzeOverWorks@threepiece.us'),
(42, 'WTB - Gram Lights 57drs', '2021-04-23 15:40:12', 'dookieboi42@yahoo.com'),
(43, 'FS - 326Power 32k Spring Rate springs ', '2021-04-23 15:43:34', 'TridentGumLover@88rising.com'),
(44, 'WTB - Rear Camber Arms for FA5', '2021-04-23 15:46:32', 'intelfan@dell.com'),
(45, 'We can Extend your LCAs here!', '2021-04-23 15:47:16', 'randomshop@gmail.com'),
(46, 'GT86 Front Angle Kits Here!', '2021-04-23 15:49:39', 'supbirdy@yahoo.com'),
(47, 'Someone Have A trailer for rent?', '2021-04-23 15:51:04', 'ILoveArin@gmail.com'),
(48, 'DC5 Extra Parts for Sale!', '2021-04-23 15:51:53', 'jenniekimlover@gmail.com'),
(49, 'Initial D vs Wangan Midnight', '2021-04-23 15:52:45', 'jisookimstan@blackpink.com'),
(50, 'Lan EVO FS/FT', '2021-04-23 15:53:41', 'izone@mbc.kr'),
(51, 'The Return of Regamasters', '2021-04-23 15:55:08', 'ihatekpop@gmail.com'),
(52, 'Enjuku Racing Dont Buy From THEM!', '2021-04-23 15:56:27', 'eunbi@izone.com'),
(53, 'Best R33 Reps - Square G33', '2021-04-23 15:57:10', 'joyuri@izone.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `forum_topics`
--
ALTER TABLE `forum_topics`
  ADD PRIMARY KEY (`topic_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `forum_topics`
--
ALTER TABLE `forum_topics`
  MODIFY `topic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
